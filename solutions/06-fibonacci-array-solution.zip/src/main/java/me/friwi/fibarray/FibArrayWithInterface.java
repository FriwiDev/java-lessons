package me.friwi.fibarray;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class FibArrayWithInterface implements Set<Integer> {
    //Create an internal Set to manage our data - we do not need to reinvent the wheel
    private Set<Integer> internalSet = new TreeSet<>();

    //We want to change the behaviour of the "add" method
    @Override
    public boolean add(Integer i) {
        //Check if "i" is a fibonacci number
        if(!FibonacciUtils.isFibonacci(i))throw new NoFibonacciException("The number \""+i+"\" is no fibonacci number!");
        //Let the internal set perform the add
        //The return value indicates whether the element was already present
        return internalSet.add(i);
    }

    //Bonus points: There is also an addAll method
    @Override
    public boolean addAll(Collection<? extends Integer> collection) {
        //Check if all "i" are fibonacci numbers
        for(Integer i : collection) {
            if (!FibonacciUtils.isFibonacci(i)) {
                throw new NoFibonacciException("The number \"" + i + "\" is no fibonacci number!");
            }
        }
        //Let the internal set perform the add
        //The return value indicates whether the elements were already present
        return internalSet.addAll(collection);
    }

    //All other methods are only wrapped using the child object "internalSet" (we do not want to implement them)

    @Override
    public int size() {
        return internalSet.size();
    }

    @Override
    public boolean isEmpty() {
        return internalSet.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return internalSet.contains(o);
    }

    @Override
    public Iterator<Integer> iterator() {
        return internalSet.iterator();
    }

    @Override
    public Object[] toArray() {
        return internalSet.toArray();
    }

    @Override
    public <T> T[] toArray(T[] ts) {
        return internalSet.toArray(ts);
    }

    @Override
    public boolean remove(Object o) {
        return internalSet.remove(o);
    }

    @Override
    public boolean containsAll(Collection<?> collection) {
        return internalSet.containsAll(collection);
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        return internalSet.retainAll(collection);
    }

    @Override
    public boolean removeAll(Collection<?> collection) {
        return internalSet.removeAll(collection);
    }

    @Override
    public void clear() {
        internalSet.clear();
    }
}
