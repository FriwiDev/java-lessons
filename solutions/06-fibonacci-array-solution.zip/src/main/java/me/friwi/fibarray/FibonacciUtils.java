package me.friwi.fibarray;

/**
 * Small util class to check fibonacci numbers
 */
public class FibonacciUtils {
    /**
     * Checks whether a number is a fibonacci number
     * @param i The number to check
     * @return true if "i" is a fibonacci number, false otherwise
     */
    public static boolean isFibonacci(int i){
        //Initialize the begin of the sequence
        int a = 1;
        int b = 1;
        //When we reached our "i", or are beyond it, we can tell if its a fibonacci number or not
        while(a<i){
            //Backup an old a
            int c = a;
            //Calculate the next fibonacci number and store it in a
            a = a + b;
            //Assign the old value of a to b
            b = c;
        }
        //When our last fibonacci number is "i", "i" is a fibonacci number. Else its not
        return a==i;
    }
}
