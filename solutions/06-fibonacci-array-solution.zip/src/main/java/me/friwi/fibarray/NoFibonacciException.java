package me.friwi.fibarray;

/**
 * This class has to extend RuntimeException as it has to be unchecked
 * We can not add a new throws declaration to the "add" method of our Set
 */
public class NoFibonacciException extends RuntimeException {
    public NoFibonacciException(String msg) {
        super(msg);
    }
}
