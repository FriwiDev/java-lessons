package me.friwi.fibarray;

import java.util.Set;

public class Main {
    /**
     * We test both implementations here, the correct one for the 6th exercise is the interface one
     * @param args
     */
    public static void main(String args[]){
        FibArrayWithInterface fibIntf = new FibArrayWithInterface();
        FibArrayWithInheritance fibInh = new FibArrayWithInheritance();
        System.out.println("--- Interface variant ---");
        test(fibIntf);
        System.out.println("--- Inheritance variant ---");
        test(fibInh);
    }
    public static void test(Set<Integer> set){
        for (int i = 0; i < 100; i++) {
            try {
                set.add(i);
                System.out.println(i);
            } catch (NoFibonacciException e) {
                //Ignore for better console output
            }
        }
    }
}
