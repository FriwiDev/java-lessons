package me.friwi.fibarray;

import java.util.Collection;
import java.util.TreeSet;

public class FibArrayWithInheritance extends TreeSet<Integer> {
    //We want to change the behaviour of the "add" method
    @Override
    public boolean add(Integer i){
        //Check if "i" is a fibonacci number
        if(!FibonacciUtils.isFibonacci(i))throw new NoFibonacciException("The number \""+i+"\" is no fibonacci number!");
        //Let the parent class perform the add
        //The return value indicates whether the element was already present
        return super.add(i);
    }

    //Bonus points: There is also an addAll method
    @Override
    public boolean addAll(Collection<? extends Integer> collection) {
        //Check if all "i" are fibonacci numbers
        for(Integer i : collection) {
            if (!FibonacciUtils.isFibonacci(i)) {
                throw new NoFibonacciException("The number \"" + i + "\" is no fibonacci number!");
            }
        }
        //Let the parent class perform the add
        //The return value indicates whether the elements were already present
        return super.addAll(collection);
    }
}
